#include "hello.h"

int main() {
    // call a function in another file
    func();

    return(0);
}