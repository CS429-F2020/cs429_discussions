#include <stdio.h>
#include "hello.h"

void func(void) {
    printf("Hello World\n");
    return;
}